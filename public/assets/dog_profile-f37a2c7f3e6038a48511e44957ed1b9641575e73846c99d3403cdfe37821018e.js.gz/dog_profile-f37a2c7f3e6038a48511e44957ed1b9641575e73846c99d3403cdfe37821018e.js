$( document ).ready(function(){
    $('.slider').slider({full_width: true});//slider init
});

$(document).ready(function(){
  $('.ui.video').video();
});
